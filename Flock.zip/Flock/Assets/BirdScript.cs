﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*  
    Gaming Development
    Flocking Script
    Anthony Garrard
    2/18/21
*/



public class BirdScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log(this.gameObject.name + " Reporting for duty");

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
